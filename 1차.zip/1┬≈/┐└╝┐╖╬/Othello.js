let canvas = document.getElementById("myCanvas");
let ctx = canvas.getContext("2d");
let areaArcList=[];
let whiteArcList = [];
let blackArcList = [];
let turn = "black";

let oringinX = 100;
let oringinY = 100;
let lineGap = 50;
let lineCount = 9;

function drawGrid(){
    ctx.beginPath();
    //세로그리기
    for(let i=0; i<lineCount; i++){
        let startX = oringinX +lineGap * i;
        let startY = oringinY;
        let endX = startX;
        let endY = oringinY + (lineCount-1) * lineGap;
        ctx.moveTo(startX, startY);
        ctx.lineTo(endX, endY);
        ctx.stroke();
    }
    //가로그리기
    for(let i =0; i<lineCount; i++){
        let startX = oringinX;
        let startY = oringinY + lineGap * i;
        let endX = oringinX + (lineCount-1) * lineGap;
        let endY = startY;
        ctx.moveTo(startX, startY);
        ctx.lineTo(endX, endY);
        ctx.stroke();
    }
    ctx.closePath();
}

//네모안에 원형 객체 위치를 추가
function setAreaArcList(){
    let oringinX = 125;
    let oringinY = 125;
    let lineCount1 = lineCount-1;
    for(let i =0; i <lineCount-1; i++){
        for(let j = 0; j <lineCount-1; j++){
            let arc ={
                x : oringinX + j * lineGap,
                y : oringinY + i * lineGap,
                radius : 20,
                color : "lightgray"
            };
            areaArcList.push(arc);
        }
    }
}
function InArc(x, y, mx, my, radius){
    let hy = Math.sqrt((x - mx) ** 2 + (y - my) ** 2);
    if(hy <= radius) {
        return true;
    }
    return false;
}

window.addEventListener('click' , clickmouse);
function clickmouse(e){
    let rect = canvas.getBoundingClientRect();
    let mx = e.clientX - ctx.canvas.offsetLeft;
    let my = e.clientY - ctx.canvas.offsetTop;
    for(let i=0; i<areaArcList.length; i++){
        let check = InArc(areaArcList[i].x, areaArcList[i].y, mx, my, areaArcList[i].radius);
        if(check) {
            let arc = {
                x : areaArcList[i].x,
                y : areaArcList[i].y,
                radius : areaArcList[i].radius,
                color : turn
            };
            areaArcList.splice(i, 1);
            if(turn =="white"){
                whiteArcList.push(arc);
                flipDiscs(arc, "white")
                turn = "black";
            }else{
                blackArcList.push(arc);
                flipDiscs(arc, "black")
                turn = "white";
            }
            draw();
            break;
        }
    }
    console.log("All", areaArcList.length);
    console.log("white", whiteArcList.length);
    console.log("black", blackArcList.length);
    if(areaArcList.length == 0){
        winnercheck();
    }
}

function draw(){
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    drawGrid();
    for(let i=0; i<whiteArcList.length; i++){
        drawArc(whiteArcList[i]);
    }
    for(let i=0; i<blackArcList.length; i++){
        drawArc(blackArcList[i]);
    }
}

function drawArc(arc){
    ctx.beginPath();
    ctx.arc(arc.x, arc.y, arc.radius, 0, Math.PI * 2);
    ctx.stroke();
    ctx.closePath();

    ctx.beginPath();
    ctx.arc(arc.x, arc.y, arc.radius, 0, Math.PI * 2);
    ctx.fillStyle = arc.color;
    ctx.fill();
    ctx.closePath();
}

let resetButton = document.querySelector("#reset");
resetButton.addEventListener('click', reset);
function reset(){
    areaArcList = [];
    whiteArcList = [];
    blackArcList = [];
    turn = "black";
    setAreaArcList();
}

function flipDiscs(arc, color) {
    let d = [
        { dx: 50, dy: 0 }, { dx: -50, dy: 0 },
        { dx: 0, dy: 50 }, { dx: 0, dy: -50 },
        { dx: 50, dy: 50 }, { dx: -50, dy: -50 },
        { dx: 50, dy: -50 }, { dx: -50, dy: 50 }
    ];
    for(let dir of d){
        let ToFlip = [];
        let x = arc.x + dir.dx;
        let y = arc.y + dir.dy;
        let found = false;
        
        while (InList(x, y, color ==="white" ? "black" : "white")) {
            ToFlip.push({x, y});
            x += dir.dx;
            y += dir.dy;
            found = true;
        }

        if(found && InList(x, y, color)){ 
            for(let i of ToFlip) {
                flipDisc(i.x, i.y, color);
            }
        }
    }
}
//
function flipDisc(x, y, color) {
    let Remove = color === "white" ? blackArcList : whiteArcList;
    let AddTo = color ==="white" ? whiteArcList : blackArcList;
    for(let i =0; i <Remove.length; i++){
        if(Remove[i].x === x && Remove[i].y === y ){
            Remove.splice(i, 1);
            break;
        }
    }
    AddTo.push({x, y, radius : 20, color});
}
//
function InList(x, y, color){
    let list = color === "white" ? whiteArcList : blackArcList
    for(let arc of list){
        if(arc.x === x && arc.y === y){
            return true;
        }
    }
    return false;
}

function winnercheck(){
    if(whiteArcList.length <blackArcList.length){
        alert("흑 승")
    }else if(whiteArcList.length > blackArcList.length){
        alert("백 승");
    }else if(whiteArcList.length == blackArcList.length){
        alert("무승부")
    }
}

setAreaArcList();
setInterval(draw, 10);//반복해서 실행되는 함수의 지연을 설정